/// miniprogram/pages/deployService/index.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      randnum:Math.random()*10,
  num:'',
  num1: '',
  num2:'',
  num3:0,
  result:0,
  flag:0
    },
    inputhandler(e){
  this.setData({
    num:e.detail.value
  })
    },
    inputhandler1(e){
      this.setData({
        num1:e.detail.value
      })
        },
        inputhandler2(e){
          this.setData({
            num2:e.detail.value
          })
            },
        buttonhandler:function(){
       
    
         var good=this.data.num1
                
             wx.navigateTo({
          url: '../../pages/yjh/yjh?gooD=' +good,
               
            })
                 
        },
  });
  