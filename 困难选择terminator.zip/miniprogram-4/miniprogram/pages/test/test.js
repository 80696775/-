// miniprogram/pages/deployService/index.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        show: false,
        show2: false,
        show3: false,
        randnum:Math.random()*10,
        randnum2:Math.random()*10,
        randnum3:Math.random()*10,
        imgUrl: [
            'https://bpic.588ku.com/back_origin_min_pic/20/06/20/d8b4dab0e900d693382ce80d4d6e9b05.jpg',
            'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg95.699pic.com%2Fxsj%2F0u%2Fe3%2Fqk.jpg%21%2Ffw%2F700%2Fwatermark%2Furl%2FL3hzai93YXRlcl9kZXRhaWwyLnBuZw%2Falign%2Fsoutheast&refer=http%3A%2F%2Fimg95.699pic.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1672058613&t=f0f8c461f3c96d3cc481faacf757d0b1',
            'https://p0.itc.cn/q_70/images03/20221125/bf224f2005c9442bb7ba9b3a9599dfdf.jpeg'
        ],
    },
    showPopup() {
        this.setData({ show: true });
        this.setData({ show2: true });
        this.setData({ show3: true });
      },
    
      onClose() {
        this.setData({ show: false });
        this.setData({ show2: false });
        this.setData({ show3: false });
      },
      handler(){
        this.setData({show:1,
        randnum:Math.random()*10});
      },
      handler2(){
        this.setData({show2:1,
        randnum2:Math.random()*10});
      },
      handler3(){
        this.setData({show3:1,
        randnum3:Math.random()*10});
      },
    onPullDownRefresh: function(){
        this.setData({
            randnum:Math.random()*10,
            randnum2:Math.random()*10,
            randnum3:Math.random()*10

        })
        wx.stopPullDownRefresh()
        },
            
        
  });
  