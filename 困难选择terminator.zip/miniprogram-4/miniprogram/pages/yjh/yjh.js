// pages/yjh/yjh.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
    number1:0
    },
    onLoad:function(options){
        var good=(options.gooD ? options.gooD :'');
       
     this.setData({
            number1:good,
         
        })
    }
    
})