
// pages/demo3/demo3.js
Page({
    /**
     * 页面的初始数据
     */
    data: {
      classStyle: '',
      value:0,
      id:'default',
      show: false,
      flag1:0,
      flag2:1,
     flag3:0
    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
  
    },
    click() {
      wx.vibrateShort();
      this.setData({
        classStyle: 'animal',
        id:'font',
        value:this.data.value+1,
      });
      setTimeout(() => {
        this.setData({
          classStyle: '',
          //id:'default'
        });
      }, 100);
      setTimeout(() => {
        this.setData({
          id:'default'
        });
      }, 500);
      
    },

    start() {
        const countDown = this.selectComponent('.control-count-down');
        countDown.start();
      },
    
      pause() {
        const countDown = this.selectComponent('.control-count-down');
        countDown.pause();
      },
    
      reset() {
        const countDown = this.selectComponent('.control-count-down');
        countDown.reset();
      },
    
      finished() {
       this.setData({show:true})
      },
      showPopup() {
        this.setData({ show: true });
      },
    
      onClose() {
        this.setData({ show: false });
      },
      
      onPullDownRefresh: function(){
        this.setData({
            value:0

        })
        wx.stopPullDownRefresh()
        },
        click1(){
            this.setData({flag1:1});
            this.setData({flag2:false});
            this.setData({flag3:1});
            this.setData({value:0});
        },
        click2(){
            this.setData({flag1:0});
            this.setData({flag2:1});
            this.setData({flag3:0});
            this.setData({value:0});
        }
  })
  