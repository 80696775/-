Page({

  data: {
    value:'',
    imgUrl: [
        'http://d.ifengimg.com/mw978_mh598/p3.ifengimg.com/a/2016_39/350f3e6b36d76f8_size52_w600_h393.jpg',
        'http://pic.yupoo.com/fotomag/fbb229a4/54dfa143.jpg',
        'https://pic4.zhimg.com/v2-0a4843aa6a6a9311aaa38b61a4b7c253_r.jpg',
        
    ],
    show: false,
    actions: [
      {name: "学习"},
      {name: "午餐" },
      {name: "自定义"}
    ],
  },

onTap(){
    this.setData({
        show:true
    })
},
onClose(){
    this.setData({
        show:false
    })
},
onSelect(res){
    console.log(res.detail.name)
    this.setData({
        value:res.detail.name
    })
},
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})